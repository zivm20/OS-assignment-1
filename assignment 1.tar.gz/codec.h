#ifndef CODEC_H_  
#define CODEC_H_
#include <ctype.h>
int encode(char* src, char* dst, int len);
int decode(char* src, char* dst, int len);


#endif